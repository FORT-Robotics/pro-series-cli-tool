import json
from enum import Enum
from typing import Tuple
from urllib.parse import urljoin

import requests

from fort_cli_cfg.validators import validate_mac_address


# https://dev.api.fortrobotics.com/doc/swagger/index.html?url=/doc/swagger/spec
# https://fint-api-dev.azurewebsites.net/doc/swagger/index.html?url=/doc/swagger/spec

class DevType(Enum):
    FRC = 1
    EPC = 3


def get_user_credentials() -> Tuple[str, str]:
    import getpass
    user = input("Enter User ID (email): ")
    pass_ = getpass.getpass()
    return (user, pass_)


def login(uri_root: str, user: str, pass_: str) -> str:
    auth_payload = {"email": user, "password": pass_}
    auth_url = urljoin(uri_root, "v1/authentication")
    auth_headers = {"accept": "application/json", "Content-Type": "application/json"}
    auth_response = requests.post(auth_url, headers=auth_headers, data=json.dumps(auth_payload))
    auth_rsp = json.loads(auth_response.text)
    token = "SessionKey " + auth_rsp['sessionToken']
    return token


# Individual device configuration
def get_device_config(uri_root: str, token: str, device_sn: str) -> dict:
    dev_url = urljoin(uri_root, "v1/devices/by")
    dev_headers = {'accept': 'application_json', 'Authorization': token}
    try:
        response = requests.get(
            dev_url, params={'serial': device_sn}, headers=dev_headers
        )

        device_data = json.loads(response.text)
        device_uuid = device_data['id']
    except:
        print(response)
        raise Exception("Error fetching device-id by serial")

    sync_url = urljoin(uri_root, "v1/devices/{id}/safety-configs/syncs")
    sync_headers = {'accept': 'application_json', 'Authorization': token}
    try:
        sync_response = requests.post(sync_url.format(id=device_uuid), headers=sync_headers)

        # return sync_response
        sync_rsp = json.loads(sync_response.text)
        config = sync_rsp['configurationBlob']
    except:
        print(response)
        raise Exception("Error fetching device safety-config from POST ")

    # Add a field to the returned config data for type indication
    config['type'] = DevType[device_data['type']].name

    return config


def get_peer_mac(cfg: dict, peer_num: int = 0) -> str:
    pn = str(peer_num)
    try:
        premac = cfg['body']['scm2']['NET']['peers'][pn]['blue0']['mac'].strip()
    except:
        raise Exception("ERROR: Could not get peer MAC from config")
    try:
        validate_mac_address(premac)
        return premac
    except:
        formac = ':'.join(premac[i:i + 2] for i in range(0, len(premac), 2))
    return formac

# token = login("test.user1@fortrobotics.com", "1234")
# FRC
# config = get_device_config(token, "7xne5xjoyo")
# EPC
# config = get_device_config(token, "ipgqd6x5n6")
# mac = getPeerMac(config, 0)
# print(mac)
