# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['fort_cli_cfg', 'fort_cli_cfg.coap', 'fort_cli_cfg.data']

package_data = \
{'': ['*']}

install_requires = \
['aiocoap==0.4b3',
 'cbor2>=5.4.2,<6.0.0',
 'invoke>=1.6.0,<2.0.0',
 'linuxfd>=1.5,<2.0',
 'pyserial>=3.5,<4.0',
 'requests>=2.25.0,<3.0.0',
 'simple-term-menu>=1.2.1,<2.0.0',
 'sliplib>=0.6.2,<0.7.0',
 'typing-extensions>=3.10.0.2,<4.0.0.0']

extras_require = \
{':python_version < "3.7"': ['async_generator>=1.10,<2.0'],
 ':python_version < "3.8"': ['importlib-metadata>=4.8.3,<5.0.0']}

entry_points = \
{'console_scripts': ['fort_cli_cfg = fort_cli_cfg:cfgtool',
                     'serial_coap_proxy = fort_cli_cfg.serial_coap_proxy:main',
                     'serial_udp_bridge = fort_cli_cfg.serial_udp_bridge:main']}

setup_kwargs = {
    'name': 'fort-cli-cfg',
    'version': '2.1.1',
    'description': 'Basic configuration utility for FORT Devices',
    'long_description': 'None',
    'author': 'FORT Robotics',
    'author_email': 'developers@fortrobotics.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'extras_require': extras_require,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
